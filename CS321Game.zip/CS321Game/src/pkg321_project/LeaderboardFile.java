/*
 * Resources: https://www.w3schools.com/java/java_files_create.asp and https://stackoverflow.com/questions/21059085/how-can-i-create-a-file-in-the-current-users-home-directory-using-java and https://www.w3schools.com/java/java_files_read.asp
 */
package pkg321_project;

/**
 *
 * @author Sierra Laney
 */
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.FileWriter; 
import java.util.Scanner; 
import javax.swing.*;


public final class LeaderboardFile {
String player = "";
LeaderboardFile() {
createDirectory();
createFile();
readFile();
    
}

    
    public void createDirectory() {
     String path = System.getProperty("user.home");
     path += File.separator + "CS321-01 Team 5";
     File customDir = new File(path);

     if (customDir.exists()) {
    System.out.println(customDir + " already exists");
    } else if (customDir.mkdirs()) {
    System.out.println(customDir + " was created");
    } else {
    System.out.println(customDir + " was not created");
    }
     }
    
    public void createFile() {
     try {
      String path = System.getProperty("user.home");
      path += File.separator + "CS321-01 Team 5";
      File myObj = new File(path + File.separator + "players.txt");
      if (myObj.createNewFile()) {
        System.out.println("File created: " + myObj.getName());
      } else {
        System.out.println("File already exists.");
      }
    } catch (IOException e) {
      System.out.println("An error occurred.");
      e.printStackTrace();
    }
     }
    
    public void updateLeaderBoard(JTextArea a, String username) {
    try {
      String path = System.getProperty("user.home");
      path += File.separator + "CS321-01 Team 5";
      FileWriter myWriter = new FileWriter(path + File.separator + "players.txt");
      myWriter.write(username + "\n");
      myWriter.close();
      System.out.println("Successfully wrote to the file.");
      a.setText("Your username has been added!");
    } catch (IOException e) {
      System.out.println("An error occurred.");
      a.setText("There has been an error adding your username.");
      e.printStackTrace();
    }
  }
    public void readFile() {
        try {
      String path = System.getProperty("user.home");
      path += File.separator + "CS321-01 Team 5";
      File myObj = new File(path + File.separator + "players.txt");
      Scanner myReader = new Scanner(myObj);
      while (myReader.hasNextLine()) {
        player += myReader.nextLine();
      }
      myReader.close();
    } catch (FileNotFoundException e) {
      System.out.println("An error occurred.");
      e.printStackTrace();
    }
    }
}
